



import React, { useState } from "react";
import { TextField, Button, Box } from "@mui/material";
import API from "../../api/axios";

export default function AdminAddMovie({ onAdd }) {
  const [movie, setMovie] = useState({ title: "", description: "" });

  const handleChange = (e) => setMovie({ ...movie, [e.target.name]: e.target.value });

  const handleAdd = async () => {
    try {
      await API.post("/movies/add", movie);
      alert("Movie added");
      setMovie({ title: "", description: "" });
      onAdd();
    } catch (err) {
      alert(err.response?.data?.message || "Add failed");
    }
  };

  return (
    <Box sx={{ my: 2 }}>
      <TextField label="Title" name="title" value={movie.title} onChange={handleChange} sx={{ mr: 2 }} />
      <TextField label="Description" name="description" value={movie.description} onChange={handleChange} sx={{ mr: 2 }} />
      <Button variant="contained" onClick={handleAdd}>Add Movie</Button>
    </Box>
  );
}
