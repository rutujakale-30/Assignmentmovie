


import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { Button, Card, CardContent, Typography, Box } from "@mui/material";
import AdminAddMovie from "./AdminAddMovie";
import AdminEditMovie from "./AdminEditMovie"; // Import edit component

export default function AdminDashboard() {
  const [movies, setMovies] = useState([]);
  const [reload, setReload] = useState(false);
  const [editMovieId, setEditMovieId] = useState(null); // Track which movie is being edited

  const fetchMovies = async () => {
    try {
      const res = await API.get("/movies");
      setMovies(res.data);
    } catch (err) {
      alert("Failed to fetch movies");
    }
  };

  useEffect(() => {
    fetchMovies();
  }, [reload]);

  const handleDelete = async (id) => {
    try {
      await API.delete(`/movies/delete/${id}`);
      alert("Deleted successfully");
      setReload(!reload);
    } catch (err) {
      alert(err.response?.data?.message || "Delete failed");
    }
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4">Admin Dashboard</Typography>

      {/* Add Movie Form */}
      <AdminAddMovie onAdd={() => setReload(!reload)} />

      {/* Edit Movie Form */}
      {editMovieId && (
        <AdminEditMovie
          movieId={editMovieId}
          onUpdate={() => setReload(!reload)}
          onClose={() => setEditMovieId(null)}
        />
      )}

      {/* Movie List */}
      {movies.map((m) => (
        <Card key={m._id} sx={{ mt: 2 }}>
          <CardContent>
            <Typography variant="h6">{m.title}</Typography>
            <Typography>{m.description}</Typography>

            <Box sx={{ mt: 1 }}>
              <Button
                variant="contained"
                color="primary"
                sx={{ mr: 1 }}
                onClick={() => setEditMovieId(m._id)} // Open edit form
              >
                Edit
              </Button>

              <Button
                variant="contained"
                color="error"
                onClick={() => handleDelete(m._id)}
              >
                Delete
              </Button>
            </Box>
          </CardContent>
        </Card>
      ))}
    </Box>
  );
}
