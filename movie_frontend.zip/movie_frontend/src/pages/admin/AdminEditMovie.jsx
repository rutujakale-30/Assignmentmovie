


import React, { useState, useEffect } from "react";
import { TextField, Button, Box } from "@mui/material";
import API from "../../api/axios";

export default function AdminEditMovie({ movieId, onUpdate, onClose }) {
  const [movie, setMovie] = useState({ title: "", description: "" });

  // Fetch movie details by ID
  useEffect(() => {
    const fetchMovie = async () => {
      try {
        const res = await API.get(`/movies/${movieId}`);
        setMovie({ title: res.data.title, description: res.data.description });
      } catch (err) {
        alert(err.response?.data?.message || "Cannot fetch movie");
      }
    };
    fetchMovie();
  }, [movieId]);

  const handleChange = (e) => setMovie({ ...movie, [e.target.name]: e.target.value });

  const handleUpdate = async () => {
    try {
      await API.put(`/movies/edit/${movieId}`, movie);
      alert("Movie updated successfully");
      onUpdate(); // refresh parent list
      onClose(); // close edit form
    } catch (err) {
      alert(err.response?.data?.message || "Update failed");
    }
  };

  return (
    <Box sx={{ p: 2, border: "1px solid #ccc", mt: 2 }}>
      <TextField label="Title" name="title" value={movie.title} onChange={handleChange} sx={{ mb: 2, width: "100%" }} />
      <TextField
        label="Description"
        name="description"
        value={movie.description}
        onChange={handleChange}
        sx={{ mb: 2, width: "100%" }}
      />
      <Button variant="contained" onClick={handleUpdate} sx={{ mr: 1 }}>
        Update
      </Button>
      <Button variant="outlined" onClick={onClose}>
        Cancel
      </Button>
    </Box>
  );
}
