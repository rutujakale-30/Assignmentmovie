


import React from "react";
import { Box, Typography, Tabs, Tab } from "@mui/material";
import Home from "./Home";        // All movies
import Search from "./Search";    // Search movies
import SortMovies from "./SortMovies"; // Sort movies

export default function UserDashboard() {
  const [tab, setTab] = React.useState(0);

  const handleChange = (event, newValue) => {
    setTab(newValue);
  };

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4" sx={{ mb: 2 }}>
        User Dashboard
      </Typography>

      {/* Tabs for navigation */}
      <Tabs value={tab} onChange={handleChange} sx={{ mb: 2 }}>
        <Tab label="All Movies" />
        <Tab label="Search Movies" />
        <Tab label="Sort Movies" />
      </Tabs>

      {/* Tab content */}
      {tab === 0 && <Home />}
      {tab === 1 && <Search />}
      {tab === 2 && <SortMovies />}
    </Box>
  );
}
