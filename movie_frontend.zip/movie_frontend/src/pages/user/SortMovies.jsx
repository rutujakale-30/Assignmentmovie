

import React, { useState, useEffect } from "react";
import { Box, Typography, Button, Card, CardContent } from "@mui/material";
import API from "../../api/axios";

export default function SortMovies() {
  const [movies, setMovies] = useState([]);

  const fetchSorted = async (sortBy) => {
    try {
      const res = await API.get(`/movies/sort?by=${sortBy}`);
      setMovies(res.data);
    } catch (err) {
      console.error("Error fetching sorted movies:", err);
      setMovies([]);
    }
  };

  useEffect(() => {
    fetchSorted("title"); // Default sort
  }, []);

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4" sx={{ mb: 2 }}>
        Sorted Movies
      </Typography>

      <Box sx={{ my: 2 }}>
        <Button variant="contained" onClick={() => fetchSorted("title")} sx={{ mr: 1 }}>
          Sort by Title
        </Button>
        <Button variant="contained" onClick={() => fetchSorted("rating")} sx={{ mr: 1 }}>
          Sort by Rating
        </Button>
        <Button variant="contained" onClick={() => fetchSorted("releaseDate")}>
          Sort by Release Date
        </Button>
      </Box>

      {movies.map((m) => (
        <Card key={m._id} sx={{ mb: 2 }}>
          <CardContent>
            <Typography variant="h6">{m.title}</Typography>
            <Typography>Rating: {m.rating}</Typography>
            <Typography>Release Date: {m.releaseDate}</Typography>
            <Typography>{m.description}</Typography>
          </CardContent>
        </Card>
      ))}
    </Box>
  );
}
