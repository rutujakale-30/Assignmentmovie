


import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { TextField, Card, CardContent, Typography, Box } from "@mui/material";

export default function Search() {
  const [query, setQuery] = useState("");
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    if (query.length > 1) {
      API.get(`/movies/search?query=${query}`)
        .then((res) => setMovies(res.data))
        .catch(() => setMovies([]));
    }
  }, [query]);

  return (
    <Box sx={{ p: 2 }}>
      <TextField
        label="Search Movie"
        fullWidth
        onChange={(e) => setQuery(e.target.value)}
        sx={{ mb: 2 }}
      />
      {movies.map((m) => (
        <Card key={m._id} sx={{ mb: 2 }}>
          <CardContent>
            <Typography variant="h6">{m.title}</Typography>
            <Typography>{m.description}</Typography>
          </CardContent>
        </Card>
      ))}
    </Box>
  );
}

