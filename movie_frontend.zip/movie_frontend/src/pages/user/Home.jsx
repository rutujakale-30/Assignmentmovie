



import React, { useEffect, useState } from "react";
import API from "../../api/axios";
import { Card, CardContent, Typography, Box } from "@mui/material";

export default function Home() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const res = await API.get("/movies"); // GET /api/movies/
        setMovies(res.data);
      } catch (err) {
        alert("Cannot fetch movies");
      }
    };
    fetchMovies();
  }, []);

  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="h4">Movies</Typography>
      {movies.map((m) => (
        <Card key={m._id} sx={{ mt: 2 }}>
          <CardContent>
            <Typography variant="h6">{m.title}</Typography>
            <Typography>{m.description}</Typography>
          </CardContent>
        </Card>
      ))}
    </Box>
  );
}
