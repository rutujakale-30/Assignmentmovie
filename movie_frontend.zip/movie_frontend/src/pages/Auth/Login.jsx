import React, { useState, useContext } from "react";
import { TextField, Button } from "@mui/material";
import API from "../../api/axios";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../../context/AuthContext";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const res = await API.post("/auth/login", { email, password });

      login(res.data.user, res.data.token);

      // 🔥 ROLE BASED REDIRECT
      if (res.data.user.role === "admin") {
        navigate("/admin");
      } else {
        navigate("/user");
      }
    } catch {
      alert("Login failed");
    }
  };

  return (
    <>
      <TextField label="Email" fullWidth onChange={(e) => setEmail(e.target.value)} />
      <TextField
        label="Password"
        type="password"
        fullWidth
        onChange={(e) => setPassword(e.target.value)}
      />
      <Button onClick={handleLogin} variant="contained">
        Login
      </Button>
    </>
  );
}
