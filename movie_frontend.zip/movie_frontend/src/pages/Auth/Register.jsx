import React, { useState } from "react";
import { TextField, Button, MenuItem } from "@mui/material";
import API from "../../api/axios";
import { useNavigate } from "react-router-dom";

export default function Register() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    role: "user",
  });

  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async () => {
    try {
      await API.post("/auth/register", form);
      alert("Register successful");
      navigate("/login");
    } catch {
      alert("Register failed");
    }
  };

  return (
    <>
      <TextField name="name" label="Name" fullWidth onChange={handleChange} />
      <TextField name="email" label="Email" fullWidth onChange={handleChange} />
      <TextField
        name="password"
        type="password"
        label="Password"
        fullWidth
        onChange={handleChange}
      />

      <TextField
        select
        name="role"
        label="Role"
        fullWidth
        value={form.role}
        onChange={handleChange}
      >
        <MenuItem value="user">User</MenuItem>
        <MenuItem value="admin">Admin</MenuItem>
      </TextField>

      <Button onClick={handleSubmit} variant="contained">
        Register
      </Button>
    </>
  );
}
