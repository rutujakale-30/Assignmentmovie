import React from "react";
import { AppBar, Toolbar, Typography, Button, Box } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function Header() {
  const navigate = useNavigate();

  return (
    <AppBar position="static">
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        
        {/* App Name */}
        <Typography
          variant="h6"
          sx={{ cursor: "pointer", fontWeight: "bold" }}
          onClick={() => navigate("/")}
        >
          🎬 MovieApp
        </Typography>

        {/* Right Buttons */}
        <Box>
          <Button
            color="inherit"
            onClick={() => navigate("/register")}
            sx={{ mr: 1 }}
          >
            Register
          </Button>

          <Button
            color="inherit"
            onClick={() => navigate("/login")}
          >
            Login
          </Button>
        </Box>

      </Toolbar>
    </AppBar>
  );
}
