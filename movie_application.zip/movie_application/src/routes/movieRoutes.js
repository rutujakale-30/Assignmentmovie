



const express = require("express");
const router = express.Router();
const { protect, admin } = require("../middleware/authMiddleware");
const {
  getMovies,
  searchMovies,
  sortMovies,
  addMovie,
  editMovie,
  deleteMovie
} = require("../controllers/movieController");

// Public routes
router.get("/", getMovies);
router.get("/search", searchMovies);
router.get("/sort", sortMovies);

// Admin routes
router.post("/add", protect, admin, addMovie);
router.put("/edit/:id", protect, admin, editMovie);
router.delete("/delete/:id", protect, admin, deleteMovie);

module.exports = router;

